def convert_int_to_string(n):
    return str(n)
