import math

def round_down_float_to_int(f):
    return math.floor(f)
